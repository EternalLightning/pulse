Pulse 1.2.1.1 — Windows 10 / 11 x64 免安装版

本程序是基于 Pulse 的独立修改发行版，由 EternalLightning 维护，不代表原项目的官方发行。
原项目作者：jimmgreen 及其贡献者。原作者仓库：https://github.com/jimmgreen/pulse
发行版仓库：https://github.com/EternalLightning/pulse
Pulse 源码采用 Apache License 2.0；第三方组件遵循各自许可证。请保留 LICENSE、NOTICE 和 licenses。

解压整个文件夹后运行 Pulse.exe。请保留同目录的辅助程序、DLL、7zip 和 licenses 文件夹。
此版本无需安装，但配置、缓存和日志仍保存在当前用户的应用数据目录，并非全部数据随程序目录携带。
解压不会注册 PulseIndex 系统服务。需要全盘后台索引服务时，请使用安装版。
如需升级免安装版，请下载新版 portable ZIP 并解压到新目录。

Extract the complete folder and run Pulse.exe. Keep all helper programs, DLLs, 7zip and licenses together.
This independently modified distribution is maintained by EternalLightning; it is not an official upstream release.
Original project by jimmgreen and contributors: https://github.com/jimmgreen/pulse
Distribution: https://github.com/EternalLightning/pulse
Pulse source code is licensed under Apache License 2.0. Keep LICENSE, NOTICE and the third-party licenses.
Settings, caches and logs remain in the current user's application-data directory.
Extraction does not register the PulseIndex service. Use the installer for the system indexing service.
To upgrade the portable edition, download a new portable ZIP and extract it to a new directory.
